﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LojaGames.Migrations
{
    public partial class DbGames : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Fornece",
                columns: table => new
                {
                    Id_Fornecedor = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Razao_social = table.Column<string>(type: "TEXT", nullable: false),
                    cnpj = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fornece", x => x.Id_Fornecedor);
                });

            migrationBuilder.CreateTable(
                name: "Pedido",
                columns: table => new
                {
                    ID_Pedido = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Data = table.Column<int>(type: "INTEGER", nullable: false),
                    ID_Fornec = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pedido", x => x.ID_Pedido);
                });

            migrationBuilder.CreateTable(
                name: "PedidoItens",
                columns: table => new
                {
                    Id_Pedido_Itens = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Pedido_ID = table.Column<int>(type: "INTEGER", nullable: false),
                    Produto_ID = table.Column<int>(type: "INTEGER", nullable: false),
                    Quantidade = table.Column<decimal>(type: "TEXT", nullable: false),
                    Valor = table.Column<double>(type: "REAL", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PedidoItens", x => x.Id_Pedido_Itens);
                });

            migrationBuilder.CreateTable(
                name: "Produto",
                columns: table => new
                {
                    ID_Prod = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Descricao = table.Column<string>(type: "TEXT", nullable: false),
                    Unidade = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Produto", x => x.ID_Prod);
                });

            migrationBuilder.InsertData(
                table: "Fornece",
                columns: new[] { "Id_Fornecedor", "Razao_social", "cnpj" },
                values: new object[] { 101, "Final Fantasy", "Sé" });

            migrationBuilder.InsertData(
                table: "Fornece",
                columns: new[] { "Id_Fornecedor", "Razao_social", "cnpj" },
                values: new object[] { 102, "The Legend of Zelda", "Mooca" });

            migrationBuilder.InsertData(
                table: "Fornece",
                columns: new[] { "Id_Fornecedor", "Razao_social", "cnpj" },
                values: new object[] { 103, "Dark Souls", "Paulista" });

            migrationBuilder.InsertData(
                table: "Fornece",
                columns: new[] { "Id_Fornecedor", "Razao_social", "cnpj" },
                values: new object[] { 104, "Harvest Moon", "Paulista" });

            migrationBuilder.InsertData(
                table: "Pedido",
                columns: new[] { "ID_Pedido", "Data", "ID_Fornec" },
                values: new object[] { 11, 0, 104 });

            migrationBuilder.InsertData(
                table: "Pedido",
                columns: new[] { "ID_Pedido", "Data", "ID_Fornec" },
                values: new object[] { 12, 0, 101 });

            migrationBuilder.InsertData(
                table: "Pedido",
                columns: new[] { "ID_Pedido", "Data", "ID_Fornec" },
                values: new object[] { 13, 0, 102 });

            migrationBuilder.InsertData(
                table: "Pedido",
                columns: new[] { "ID_Pedido", "Data", "ID_Fornec" },
                values: new object[] { 14, 0, 103 });

            migrationBuilder.InsertData(
                table: "PedidoItens",
                columns: new[] { "Id_Pedido_Itens", "Pedido_ID", "Produto_ID", "Quantidade", "Valor" },
                values: new object[] { 1, 11, 1004, 6m, 20.800000000000001 });

            migrationBuilder.InsertData(
                table: "PedidoItens",
                columns: new[] { "Id_Pedido_Itens", "Pedido_ID", "Produto_ID", "Quantidade", "Valor" },
                values: new object[] { 2, 12, 1001, 5m, 20.5 });

            migrationBuilder.InsertData(
                table: "PedidoItens",
                columns: new[] { "Id_Pedido_Itens", "Pedido_ID", "Produto_ID", "Quantidade", "Valor" },
                values: new object[] { 3, 13, 1002, 5m, 50.700000000000003 });

            migrationBuilder.InsertData(
                table: "PedidoItens",
                columns: new[] { "Id_Pedido_Itens", "Pedido_ID", "Produto_ID", "Quantidade", "Valor" },
                values: new object[] { 4, 14, 1003, 1m, 20.199999999999999 });

            migrationBuilder.InsertData(
                table: "Produto",
                columns: new[] { "ID_Prod", "Descricao", "Unidade" },
                values: new object[] { 1001, "Final Fantasy", "Sé" });

            migrationBuilder.InsertData(
                table: "Produto",
                columns: new[] { "ID_Prod", "Descricao", "Unidade" },
                values: new object[] { 1002, "The Legend of Zelda", "Mooca" });

            migrationBuilder.InsertData(
                table: "Produto",
                columns: new[] { "ID_Prod", "Descricao", "Unidade" },
                values: new object[] { 1003, "Dark Souls", "Paulista" });

            migrationBuilder.InsertData(
                table: "Produto",
                columns: new[] { "ID_Prod", "Descricao", "Unidade" },
                values: new object[] { 1004, "Harvest Moon", "Paulista" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Fornece");

            migrationBuilder.DropTable(
                name: "Pedido");

            migrationBuilder.DropTable(
                name: "PedidoItens");

            migrationBuilder.DropTable(
                name: "Produto");
        }
    }
}
