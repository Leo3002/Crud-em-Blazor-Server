﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection.Emit;

namespace LojaGames.Data
{
    public class DbContexto : DbContext
    {
        public DbContexto(DbContextOptions<DbContexto> options) : base(options)
        {
        }

        public DbSet<Produto> Produto { get; set; }
        public DbSet<Fornece> Fornece { get; set; }
        public DbSet<Pedido> Pedido { get; set; }
        public DbSet<PedidoItens> PedidoItens { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Produto>().HasData(GetProduto());
            modelBuilder.Entity<Fornece>().HasData(GetFornece());
            modelBuilder.Entity<Pedido>().HasData(GetPedidos());
            modelBuilder.Entity<PedidoItens>().HasData(GetPedidosItens());
            base.OnModelCreating(modelBuilder);
        }

        private List<Fornece> GetFornece()
        {
            return new List<Fornece>()
            {
                new Fornece { Id_Fornecedor = 101, Razao_social = "Final Fantasy", cnpj ="Sé"},
                new Fornece { Id_Fornecedor = 102, Razao_social = "The Legend of Zelda", cnpj ="Mooca"},
                new Fornece { Id_Fornecedor = 103, Razao_social = "Dark Souls",  cnpj ="Paulista"},
                new Fornece { Id_Fornecedor = 104, Razao_social = "Harvest Moon", cnpj ="Paulista"}
            };
        }
        private List<Pedido> GetPedidos()
        {
            return new List<Pedido>()
            {
                new Pedido { ID_Pedido = 11, Data =  23/02/2023, ID_Fornec =104},
                new Pedido { ID_Pedido = 12, Data = 22/02/2023, ID_Fornec =101},
                new Pedido { ID_Pedido = 13, Data = 21/02/2023,  ID_Fornec =102},
                new Pedido { ID_Pedido = 14, Data = 20/02/2023, ID_Fornec =103}
            };
        }
        private List<PedidoItens> GetPedidosItens()
        {
            return new List<PedidoItens>()
            {
                new PedidoItens { Id_Pedido_Itens = 1, Pedido_ID = 11, Produto_ID =1004,Quantidade = 6,Valor = 20.8},
                new PedidoItens { Id_Pedido_Itens = 2, Pedido_ID = 12, Produto_ID =1001,Quantidade = 5,Valor = 20.5},
                new PedidoItens { Id_Pedido_Itens = 3, Pedido_ID = 13,  Produto_ID =1002, Quantidade = 5,Valor = 50.70},
                new PedidoItens { Id_Pedido_Itens = 4, Pedido_ID = 14, Produto_ID =1003,Quantidade = 1, Valor= 20.2}
            };
        }
        private List<Produto> GetProduto()
        {
            return new List<Produto>

            {
                new Produto { ID_Prod = 1001, Descricao = "Final Fantasy", Unidade ="Sé"},
                new Produto { ID_Prod = 1002, Descricao = "The Legend of Zelda", Unidade ="Mooca"},
                new Produto { ID_Prod = 1003, Descricao = "Dark Souls",  Unidade ="Paulista"},
                new Produto { ID_Prod = 1004, Descricao = "Harvest Moon", Unidade ="Paulista"}

            };
        }
    }
}
