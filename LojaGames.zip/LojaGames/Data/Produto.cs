﻿using System.ComponentModel.DataAnnotations;

namespace LojaGames.Data
{
    public class Produto
    {
        [Key] 
        public int ID_Prod { get; set; }

        public string Descricao { get; set; }
        public string Unidade { get; set; }
    }
}
