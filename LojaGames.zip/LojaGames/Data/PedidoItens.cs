﻿using System.ComponentModel.DataAnnotations;

namespace LojaGames.Data
{
    public class PedidoItens
    {
        [Key]
        public int Id_Pedido_Itens { get; set; }
        public int Pedido_ID { get; set; }
        public int Produto_ID { get; set; }

        public decimal Quantidade { get; set; }
        public double Valor { get; set; }
    }
}
