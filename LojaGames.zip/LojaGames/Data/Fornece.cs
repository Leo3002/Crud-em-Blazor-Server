﻿using System.ComponentModel.DataAnnotations;

namespace LojaGames.Data
{
    public class Fornece
    {
        [Key]
        public int Id_Fornecedor { get; set; }
        public string Razao_social { get; set; }
        public string cnpj { get; set; }
    }
}
