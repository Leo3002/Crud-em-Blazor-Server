﻿using Microsoft.EntityFrameworkCore;

namespace LojaGames.Data
{
    public class FoneceServico
    {
        private DbContexto dbContext;

       
        public FoneceServico(DbContexto dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<List<Fornece>> GetFornecedor()
        {
            return await dbContext.Fornece.ToListAsync();

        }
        public async Task<Fornece> AddFornecedor(Fornece fornecedor)
        {
            try
            {
                dbContext.Fornece.Add(fornecedor);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            return fornecedor;
        }
        public async Task<Fornece> Updatefornecedor(Fornece fornecedor)
        {
            try
            {
                var FornecedorExiste = dbContext.Fornece.FirstOrDefault(p => p.Id_Fornecedor == fornecedor.Id_Fornecedor);
                if (FornecedorExiste != null)
                {
                    dbContext.Update(fornecedor);
                    await dbContext.SaveChangesAsync();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return fornecedor;
        }
        public async Task Deletefornecedor(Fornece fornecedor)
        {
            try
            {
                dbContext.Fornece.Remove(fornecedor);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
