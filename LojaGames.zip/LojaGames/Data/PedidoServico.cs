﻿using Microsoft.EntityFrameworkCore;

namespace LojaGames.Data
{
    public class PedidoServico
    {
        private DbContexto dbContext;
        public PedidoServico(DbContexto dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<List<Pedido>> GetPedidos()
        {
            return await dbContext.Pedido.ToListAsync();

        }
        public async Task<Pedido> AddPedido(Pedido pedido)
        {
            try
            {
                dbContext.Pedido.Add(pedido);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            return pedido;
        }
        public async Task<Pedido> UpdatePedido(Pedido pedido)
        {
            try
            {
                var PedidoExiste = dbContext.Pedido.FirstOrDefault(p => p.ID_Pedido == pedido.ID_Pedido);
                if (PedidoExiste != null)
                {
                    dbContext.Update(pedido);
                    await dbContext.SaveChangesAsync();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return pedido;
        }
        public async Task DeletePedido(Pedido pedido)
        {
            try
            {
                dbContext.Pedido.Remove(pedido);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
