﻿using Microsoft.EntityFrameworkCore;

namespace LojaGames.Data
{
    public class PedidoItensServico
    {
        private DbContexto dbContext;
        public PedidoItensServico(DbContexto dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<List<PedidoItens>> GetPedidosItens()
        {
            return await dbContext.PedidoItens.ToListAsync();

        }
        public async Task<PedidoItens> AddPedidoItens(PedidoItens pedidoItens)
        {
            try
            {
                dbContext.PedidoItens.Add(pedidoItens);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            return pedidoItens;
        }
        public async Task<PedidoItens> UpdatePedidoItens(PedidoItens pedidoItens)
        {
            try
            {
                var pedidoItensExiste = dbContext.PedidoItens.FirstOrDefault(p => p.Id_Pedido_Itens == pedidoItens.Id_Pedido_Itens);
                if (pedidoItensExiste != null)
                {
                    dbContext.Update(pedidoItens);
                    await dbContext.SaveChangesAsync();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return pedidoItens;
        }
        public async Task DeletePedidoItens(PedidoItens pedidoItens)
        {
            try
            {
                dbContext.PedidoItens.Remove(pedidoItens);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
