﻿using System.ComponentModel.DataAnnotations;

namespace LojaGames.Data
{
    public class Pedido
    {
        [Key]
        public int ID_Pedido { get; set; }
        public DataType Data { get; set; }
        public int ID_Fornec { get; set; }
    }
}
