﻿using Microsoft.EntityFrameworkCore;

namespace LojaGames.Data
{
    public class ProdutoServico
    {
        private DbContexto dbContext;
        public ProdutoServico(DbContexto dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<List<Produto>> GetProduto()
        {
            return await dbContext.Produto.ToListAsync();

        }
        public async Task<Produto> AddProduto(Produto produto)
        {
            try
            {
                dbContext.Produto.Add(produto);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
            return produto;
        }
        public async Task<Produto> UpdateProduto(Produto produto)
        {
            try
            {
                var produtoExiste = dbContext.Produto.FirstOrDefault(p => p.ID_Prod == produto.ID_Prod);
                if (produtoExiste != null)
                {
                    dbContext.Update(produto);
                    await dbContext.SaveChangesAsync();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return produto;
        }
        public async Task DeleteProduto(Produto produto)
        {
            try
            {
                dbContext.Produto.Remove(produto);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
